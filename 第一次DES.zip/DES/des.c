#include "../inc/des.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

// 循环左移表
static const int SHIFTS[16] = {1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1};

// 数组S盒置换表
static const uint8_t SBox_LUT[8][64] = {
    {
        14, 0, 4, 15, 13, 7, 1, 4, 2, 14, 15, 2, 11, 13, 8, 1,
        3, 10, 10, 6, 6, 12, 12, 11, 5, 9, 9, 5, 0, 3, 7, 8,
        4, 15, 1, 12, 14, 8, 8, 2, 13, 4, 6, 9, 2, 1, 11, 7,
        15, 5, 12, 11, 9, 3, 7, 14, 3, 10, 10, 0, 5, 6, 0, 13
    },
    {
        15, 3, 1, 13, 8, 4, 14, 7, 6, 15, 11, 2, 3, 8, 4, 14,
        9, 12, 7, 0, 2, 1, 13, 10, 12, 6, 0, 9, 5, 11, 10, 5,
        0, 13, 14, 8, 7, 10, 11, 1, 10, 3, 4, 15, 13, 4, 1, 2,
        5, 11, 8, 6, 12, 7, 6, 12, 9, 0, 3, 5, 2, 14, 15, 9
    },
    {
        10, 13, 0, 7, 9, 0, 14, 9, 6, 3, 3, 4, 15, 6, 5, 10,
        1, 2, 13, 8, 12, 5, 7, 14, 11, 12, 4, 11, 2, 15, 8, 1,
        13, 1, 6, 10, 4, 13, 9, 0, 8, 6, 15, 9, 3, 8, 0, 7,
        11, 4, 1, 15, 2, 14, 12, 3, 5, 11, 10, 5, 14, 2, 7, 12
    },
    {
        7, 13, 13, 8, 14, 11, 3, 5, 0, 6, 6, 15, 9, 0, 10, 3,
        1, 4, 2, 7, 8, 2, 5, 12, 11, 1, 12, 10, 4, 14, 15, 9,
        10, 3, 6, 15, 9, 0, 0, 6, 12, 10, 11, 1, 7, 13, 13, 8,
        15, 9, 1, 4, 3, 5, 14, 11, 5, 12, 2, 7, 8, 2, 4, 14
    },
    {
        2, 14, 12, 11, 4, 2, 1, 12, 7, 4, 10, 7, 11, 13, 6, 1,
        8, 5, 5, 0, 3, 15, 15, 10, 13, 3, 0, 9, 14, 8, 9, 6,
        4, 11, 2, 8, 1, 12, 11, 7, 10, 1, 13, 14, 7, 2, 8, 13,
        15, 6, 9, 15, 12, 0, 5, 9, 6, 10, 3, 4, 0, 5, 14, 3
    },
    {
        12, 10, 1, 15, 10, 4, 15, 2, 9, 7, 2, 12, 6, 9, 8, 5,
        0, 6, 13, 1, 3, 13, 4, 14, 14, 0, 7, 11, 5, 3, 11, 8,
        9, 4, 14, 3, 15, 2, 5, 12, 2, 9, 8, 5, 12, 15, 3, 10,
        7, 11, 0, 14, 4, 1, 10, 7, 1, 6, 13, 0, 11, 8, 6, 13
    },
    {
        4, 13, 11, 0, 2, 11, 14, 7, 15, 4, 0, 9, 8, 1, 13, 10,
        3, 14, 12, 3, 9, 5, 7, 12, 5, 2, 10, 15, 6, 8, 1, 6,
        1, 6, 4, 11, 11, 13, 13, 8, 12, 1, 3, 4, 7, 10, 14, 7,
        10, 9, 15, 5, 6, 0, 8, 15, 0, 14, 5, 2, 9, 3, 2, 12
    },
    {
        13, 1, 2, 15, 8, 13, 4, 8, 6, 10, 15, 3, 11, 7, 1, 4,
        10, 12, 9, 5, 3, 6, 14, 11, 5, 0, 0, 14, 12, 9, 7, 2,
        7, 2, 11, 1, 4, 14, 1, 7, 9, 4, 12, 10, 14, 8, 2, 13,
        0, 15, 6, 12, 10, 9, 13, 0, 15, 3, 3, 5, 5, 6, 8, 11
    }
};

static const int IP_sub[64] = {
        6, 14, 22, 30, 38, 46, 54, 62, 
        4, 12, 20, 28, 36, 44, 52, 60, 
        2, 10, 18, 26, 34, 42, 50, 58, 
        0, 8, 16, 24, 32, 40, 48, 56, 
        7, 15, 23, 31, 39, 47, 55, 63, 
        5, 13, 21, 29, 37, 45, 53, 61, 
        3, 11, 19, 27, 35, 43, 51, 59, 
        1, 9, 17, 25, 33, 41, 49, 57
};

static const int IP_INV_sub[64] = {
    24, 56, 16, 48, 8, 40, 0, 32,
    25, 57, 17, 49, 9, 41, 1, 33,
    26, 58, 18, 50, 10, 42, 2, 34,
    27, 59, 19, 51, 11, 43, 3, 35,
    28, 60, 20, 52, 12, 44, 4, 36,
    29, 61, 21, 53, 13, 45, 5, 37,
    30, 62, 22, 54, 14, 46, 6, 38,
    31, 63, 23, 55, 15, 47, 7, 39
};

inline uint64_t i_permution(uint64_t input) {
  uint64_t output = 0;
  for (int i = 0; i < 64; i++) {
    output |= ((input >> (IP_sub[i])) & 1) << (~i & 0x3F);
  }
  return output;
}

inline uint64_t inverse_permutation(uint64_t input) {
  uint64_t output = 0;
  for (int i = 0; i < 64; i++) {
    output |= ((input >> (IP_INV_sub[i])) & 1) << (~i & 0x3F);
  }
  return output;
}

static const int E_sub[48] = {
    0, 31, 30, 29, 28, 27, 28, 27,
    26, 25, 24, 23, 24, 23, 22, 21,
    20, 19, 20, 19, 18, 17, 16, 15,
    16, 15, 14, 13, 12, 11, 12, 11,
    10, 9,  8,  7,  8,  7,  6,  5,
    4,  3,  4,  3,  2,  1,  0, 31
}; 

inline uint64_t E_change(uint32_t input) {
  uint64_t output = 0;
  for (int i = 0; i < 48; i++) {
    output |= ((uint64_t)((input >> (E_sub[i])) & 1)) << (47 - i);
  }
  return output;
}

static const int P_sub[32] = {
    16, 25, 12, 11, 3,  20, 4,  15,
    31, 17, 9,  6,  27, 14, 1,  22,
    30, 24, 8,  18, 0,  5,  29, 23,
    13, 19, 2,  26, 10, 21, 28, 7
};

inline uint32_t P_change(uint32_t input) {
  uint32_t output = 0;
  for (int i = 0; i < 32; i++) {
    output |= ((input >> (P_sub[i])) & 1) << (~i & 0x1F);
  }
  return output;
}

inline uint32_t S_change(uint64_t input) {
  uint32_t output = 0;
  for (int i = 0; i < 8; i++) {
    uint8_t six_bits = (input >> (42 - 6 * i)) & 0x3F;
    output = (output << 4) | SBox_LUT[i][six_bits];
  }
  return output;
}

inline uint32_t feistel(uint32_t half_block, uint64_t subkey) {
  return P_change(S_change(E_change(half_block) ^ subkey));
}

static const int PC1_sub[56] = {
    7,  15, 23, 31, 39, 47, 55, 63,
    6,  14, 22, 30, 38, 46, 54, 62,
    5,  13, 21, 29, 37, 45, 53, 61,
    4,  12, 20, 28, 1,  9,  17, 25,
    33, 41, 49, 57, 2,  10, 18, 26,
    34, 42, 50, 58, 3,  11, 19, 27,
    35, 43, 51, 59, 36, 44, 52, 60
};

inline uint64_t p_choose_one(uint64_t key) {
  uint64_t output = 0;
  for (int i = 0; i < 56; i++) {
    output |= ((key >> (PC1_sub[i])) & 1) << (55 - i);
  }
  return output;
}

static const int PC2_sub[56] = {
    42, 39, 45, 32, 55, 51, 53, 28,
    41, 50, 35, 46, 33, 37, 44, 52,
    30, 48, 40, 49, 29, 36, 43, 54,
    15, 4,  25, 19, 9,  1,  26, 16,
    5,  11, 23, 8,  12, 7,  17, 0,
    22, 3,  10, 14, 6,  20, 27, 24
};

inline uint64_t p_choose_second(uint64_t key) {
  uint64_t output = 0;
  for (int i = 0; i < 48; i++) {
    output |= ((key >> (PC2_sub[i])) & 1) << (47 - i);
  }
  return output;
}

inline uint64_t read_subkey(const unsigned char subKeys[16][6], int round) {
  uint64_t subKey = 0;
  for (int byte = 0; byte < 6; ++byte) {
    subKey = (subKey << 8) | subKeys[round][byte];
  }
  return subKey;
}

int des_make_subkeys(const unsigned char key[8], unsigned char subKeys[16][6]) {
  uint64_t key64 = 0;
  // 将字节数组转换为64位整数
  for (int i = 0; i < 8; ++i) {
    key64 = (key64 << 8) | key[i];
  }
  uint64_t permutedKey = p_choose_one(key64);
  uint32_t C = (permutedKey >> 28) & 0x0FFFFFFF;
  uint32_t D = permutedKey & 0x0FFFFFFF;
  // 生成16个子密钥
  for (int round = 0; round < 16; ++round) {
    // 左循环移位
    C = ((C << SHIFTS[round]) | (C >> (28 - SHIFTS[round]))) & 0x0FFFFFFF;
    D = ((D << SHIFTS[round]) | (D >> (28 - SHIFTS[round]))) & 0x0FFFFFFF;
    uint64_t CD = ((uint64_t)C << 28) | D;
    uint64_t subKey = p_choose_second(CD);
    for (int byte = 0; byte < 6; ++byte) {
      subKeys[round][byte] = (subKey >> (40 - byte * 8)) & 0xFF;
    }
  }
  return 0;
}

void des_encrypt_block(const unsigned char *restrict input, unsigned char subKeys[16][6],
                       unsigned char *restrict output) {
    // 将输入转换为64位整数
    uint64_t block = 0;
    for (int i = 0; i < 8; ++i) {
      block = (block << 8) | input[i];
    }
    uint64_t permuted = i_permution(block);
    uint32_t L = (permuted >> 32) & 0xFFFFFFFF;
    uint32_t R = permuted & 0xFFFFFFFF;
    uint32_t temp;
    uint64_t subKey;

    subKey = read_subkey(subKeys, 0);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 1);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 2);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 3);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 4);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 5);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 6);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 7);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 8);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 9);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 10);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 11);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 12);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 13);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 14);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 15);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    uint64_t preOutput = ((uint64_t)R << 32) | L;
    uint64_t finalBlock = inverse_permutation(preOutput);
    // 将结果转换回字节数组
    for (int i = 7; i >= 0; --i) {
      output[i] = finalBlock & 0xFF;
      finalBlock >>= 8;
    }
  }

// 单块解密
void des_decrypt_block(const unsigned char *restrict input, unsigned char subKeys[16][6],
                       unsigned char *restrict output) {
  // 将输入转换为64位整数
  uint64_t block = 0;
  for (int i = 0; i < 8; ++i) {
    block = (block << 8) | input[i];
  }
  // 初始置换 IP
  uint64_t permuted = i_permution(block);
  uint32_t L = (permuted >> 32) & 0xFFFFFFFF;
  uint32_t R = permuted & 0xFFFFFFFF;
  uint32_t temp;
    uint64_t subKey;
    subKey = read_subkey(subKeys, 15);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 14);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 13);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 12);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 11);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 10);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 9);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 8);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 7);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 6);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 5);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 4);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 3);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 2);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 1);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;

    subKey = read_subkey(subKeys, 0);
    temp = R;
    R = L ^ feistel(R, subKey);
    L = temp;
  uint64_t preOutput = ((uint64_t)R << 32) | L;
  uint64_t finalBlock = inverse_permutation(preOutput);
  // 将结果转换回字节数组
  for (int i = 7; i >= 0; --i) {
    output[i] = finalBlock & 0xFF;
    finalBlock >>= 8;
  }
}